let dbms = 
{
    MySQL: 'mysql',
    MsSQL: 'mssql',
    SQLite: 'sqlite'
};

module.exports = dbms;