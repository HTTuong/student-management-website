const AES = require('./crypt/aes')

module.exports = 
{
    AES: AES,
}