self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e840834bcd94fae338fae7e446f9d385",
    "url": "/index.html"
  },
  {
    "revision": "be9b6fa5c46bb25dccbe",
    "url": "/static/css/2.3cb76441.chunk.css"
  },
  {
    "revision": "fd4680f9d7fd4bc730a1",
    "url": "/static/css/main.73f58145.chunk.css"
  },
  {
    "revision": "be9b6fa5c46bb25dccbe",
    "url": "/static/js/2.c4ada8fd.chunk.js"
  },
  {
    "revision": "f2250deb42e7c0e00f75f8a622eeb038",
    "url": "/static/js/2.c4ada8fd.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fd4680f9d7fd4bc730a1",
    "url": "/static/js/main.5a1e3914.chunk.js"
  },
  {
    "revision": "0e5f4743c486ecd68e42",
    "url": "/static/js/runtime-main.48f1b1e4.js"
  },
  {
    "revision": "6b7a54173e2ddb75beeb430f77f9a881",
    "url": "/static/media/bg.6b7a5417.png"
  },
  {
    "revision": "5e98861f6ef1ce225121abfb3f418166",
    "url": "/static/media/getFetch.5e98861f.cjs"
  }
]);