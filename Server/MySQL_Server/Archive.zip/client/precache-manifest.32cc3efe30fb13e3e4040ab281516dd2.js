self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "96c753210627d6deec46e367af9790de",
    "url": "/index.html"
  },
  {
    "revision": "0c03cc947b507a1c4598",
    "url": "/static/css/2.3cb76441.chunk.css"
  },
  {
    "revision": "3cea3d8a2da55fd2ea23",
    "url": "/static/css/main.8f40c84c.chunk.css"
  },
  {
    "revision": "0c03cc947b507a1c4598",
    "url": "/static/js/2.9b0a05ef.chunk.js"
  },
  {
    "revision": "f2250deb42e7c0e00f75f8a622eeb038",
    "url": "/static/js/2.9b0a05ef.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3cea3d8a2da55fd2ea23",
    "url": "/static/js/main.c13bcac0.chunk.js"
  },
  {
    "revision": "0e5f4743c486ecd68e42",
    "url": "/static/js/runtime-main.48f1b1e4.js"
  },
  {
    "revision": "6b7a54173e2ddb75beeb430f77f9a881",
    "url": "/static/media/bg.6b7a5417.png"
  },
  {
    "revision": "5e98861f6ef1ce225121abfb3f418166",
    "url": "/static/media/getFetch.5e98861f.cjs"
  }
]);