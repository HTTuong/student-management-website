const loginStatus = 
{
    LoginSuccessfully: 1,
    InvalidUsername: 0,
    WrongPassword: 0
}

module.exports = loginStatus;